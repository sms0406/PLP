package com.capstore.service;

import java.util.List;

import com.capstore.model.Customers;
import com.capstore.model.Merchants;

public interface ICapStore {
	public String login(String email, String password);
	public List<Merchants> getMerchant();
	public String deleteMerchant(long merchantId);
	public List<Customers> getCustomers();
	public String deleteCustomers(long customerId);
}
