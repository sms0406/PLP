package com.capstore.service;

import java.util.List;

import com.capstore.model.Merchants;

public interface ICapStore {
	public String login(String email, String password);
	public List<Merchants> getMerchant();
	public String deleteMerchant(long merchantId);
}
