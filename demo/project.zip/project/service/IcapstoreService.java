package com.project.service;

import com.project.model.AdminLogin;

public interface IcapstoreService {
	public String login(String username, String password);

}
