package com.project.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.model.AdminLogin;
import com.project.repository.CapstoreRepository;

@Service
@Transactional
public class CapstoreImpl implements IcapstoreService {
	@Autowired
	CapstoreRepository repository;

	public String login(String username, String password) {

		Optional<AdminLogin> opt = repository.findById(username);
		AdminLogin login = opt.get();
		if (login.getPassword().equals(password)) {
			System.out.println("Successfull");
			return "Login Successful";
		} else {
			System.out.println("Failure");
			return "Login Failed";
		}

	}

}
