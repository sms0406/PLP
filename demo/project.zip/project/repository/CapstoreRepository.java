package com.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.model.AdminLogin;

public interface CapstoreRepository extends JpaRepository<AdminLogin, String> {

}
