package com.capstore.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capstore.model.Product;

public interface InventoryRepository extends JpaRepository<Product, Long> {
	@Query("from Product p where p.merchantId = ?1")
	public List<Product> findByMerchant(long merchantId);

}
