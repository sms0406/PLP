package com.capstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.model.Merchants;

public interface MerchantRepository extends JpaRepository<Merchants,Long> {

}
