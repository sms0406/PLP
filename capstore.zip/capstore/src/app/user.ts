export class User {
    customerId:any;
    customerName:any;
    email:any;
    password:any;
    cpassword:any;
    address:any;
    mobileNo:any;
    gender:any;
}
