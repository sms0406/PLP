import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminmanage',
  templateUrl: './adminmanage.component.html',
  styleUrls: ['./adminmanage.component.css']
})
export class AdminmanageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  

}
