import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service'

@Component({
  selector: 'app-showallcustomers',
  templateUrl: './showallcustomers.component.html',
  styleUrls: ['./showallcustomers.component.css']
})
export class ShowallcustomersComponent implements OnInit {
  result: any
  submitted = false;
  submit = false;
  output: any
  constructor(private service: LoginService) { }

  ngOnInit() {
    alert(sessionStorage.getItem("first"))
    this.printTransaction()
  }
  printTransaction(): void {
    this.service.viewcustomers().subscribe(data => {
      this.result = data;
      this.submit = true;

      console.log(this.result);
    });
  }
  deletecustomers(): void {
    this.service.removecustomers().subscribe(data => {
      this.output = data;
      this.submit = true;
    })
  }
}
