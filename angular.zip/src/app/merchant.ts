export class Merchant {

    merchantId : any;
    merchantName : string;
    merchantType : string;
    phoneNo :any;
    password : string;
    govtProofType : string;
    govtProof : string;


}
