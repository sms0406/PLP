import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service'

@Component({
  selector: 'app-viewmerchants',
  templateUrl: './viewmerchants.component.html',
  styleUrls: ['./viewmerchants.component.css']
})
export class ViewmerchantsComponent implements OnInit {
  result: any
  submitted = false;

  constructor(private service: LoginService) { }

  ngOnInit() {
    this.getMerchants()

  }
  getMerchants(): void {
    this.service.viewmerchants().subscribe(data => {
      this.result = data;
      this.submitted = true;
      console.log(this.result);
    });
  }

  delete(merchantId) {
    console.log(merchantId)
    this.service.deleteMerchant(merchantId).subscribe(data => {
      this.result = data;
      alert(this.result)
      window.location.reload();
    });
  }
}
