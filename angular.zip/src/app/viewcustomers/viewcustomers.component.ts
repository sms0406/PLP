import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewcustomers',
  templateUrl: './viewcustomers.component.html',
  styleUrls: ['./viewcustomers.component.css']
})
export class ViewcustomersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
