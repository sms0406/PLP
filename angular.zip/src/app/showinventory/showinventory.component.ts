import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service'

@Component({
  selector: 'app-showinventory',
  templateUrl: './showinventory.component.html',
  styleUrls: ['./showinventory.component.css']
})
export class ShowinventoryComponent implements OnInit {

  constructor(private service: LoginService) { }
  result: any
  results: any
  submitted = false;
  click=true;
  ngOnInit() { 
     this.getMerchants()

  }
  getMerchants(): void {
    this.service.viewmerchants().subscribe(data => {
      this.result = data;
      this.submitted = true;
      console.log(this.result);
    });
  }

  getProductById(merchantId): void {
    console.log(merchantId)
    this.service.getproductbyid(merchantId).subscribe(data => {
     
      this.results = data;
     
    });
    this.click=true;
    this.submitted = true;
    console.log(this.result);
  }
  searchByName(event) {
    this.result = this.result.filter(singleItem =>
      singleItem.proName.toLowerCase().includes(event.target.value.toLowerCase())
    )
  }
}
