import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  result: any
  results:any
  merchantflag = false;
  titles: Array<Object> = [
    { name: "customer" },
    { name: "merchant" }
  ]
  constructor(private router: Router, private service: LoginService) { }
  ngOnInit() {
  }
  setflag(add) {
    if (add.select == "merchant") {
      this.merchantflag = true;
      add.select = "merchant"
    }
    else {
      this.merchantflag = false;
    }
  }
  signup(add) {

    if (add.select == "customer") {
      this.service.createAccount(
        {
        name:add.Name,
        email:add.email,
        password:add.password,
        address:add.address,
        mobileNo:add.phone
       }
      ).subscribe(data=>this.results=data)
      alert("Click Okay to proceed to final registration process")
      this.router.navigate(['/'])
    }
    else if (add.select == "merchant") {
      this.service.merchantAdd(
        {
          merchantName: add.Name,
          phoneNo: add.phone,
          email: add.email,
          password: add.password,
          govtProofType: add.govt,
          govtProof: add.govt_id
        }
      ).subscribe(data => this.result = data)
      alert("Click Okay to proceed to final registration process")
      this.router.navigate(['/'])

    }
    else { }
  }
}
