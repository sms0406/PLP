package com.capstore.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

@Service
@Transactional
public class ServiceImpl implements ServiceInterface{
	

}
