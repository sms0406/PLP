package com.capstore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.model.AdminLogin;
import com.capstore.model.Merchants;
import com.capstore.repository.CapstoreRepository;
import com.capstore.repository.MerchantRepository;

@Service
@Transactional
public class CapStoreImpl implements ICapStore {
	@Autowired
	CapstoreRepository repository;
	@Autowired
	MerchantRepository merchantRepository;

	public String login(String email, String password) {

		Optional<AdminLogin> opt = repository.findById(email);
		if (opt.isPresent()) {
			AdminLogin login = opt.get();
			if (login.getPassword().equals(password)) {
				System.out.println("Successful");
				return "Login Successful";
			} else {
				System.out.println("Failure");
				return "Login Failed";
			}
		}
		else {
			return "Login Failed";
		}

	}


	public List<Merchants> getMerchant() {
		
		List<Merchants>list = new ArrayList();
		list=merchantRepository.findAll();
		return list;
	}

}
