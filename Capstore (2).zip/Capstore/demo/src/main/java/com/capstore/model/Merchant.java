package com.capstore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "merchant")
public class Merchant {
	@Column(name = "merchant_Id")
	@Id
	private long merchantId;
	@Column(name = "merchant_Name")
	private String merchantName;
	@Column(name = "merchant_Type")
	private String merchantType;
	@Column(name = "phone_No")
	private String phoneNo;
	@Column(name = "email")
	private String email;
	@Column(name = "password")
	private String password;
	@Column(name = "govt_Proof_Type")
	private String govtProofType;
	@Column(name = "govt_Proof")
	private String govtProof;

	public long getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(long merchantId) {
		this.merchantId = merchantId;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getMerchantType() {
		return merchantType;
	}

	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGovtProofType() {
		return govtProofType;
	}

	public void setGovtProofType(String govtProofType) {
		this.govtProofType = govtProofType;
	}

	public String getGovtProof() {
		return govtProof;
	}

	public void setGovtProof(String govtProof) {
		this.govtProof = govtProof;
	}

}
