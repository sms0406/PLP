import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service'

@Component({
  selector: 'app-showallcustomers',
  templateUrl: './showallcustomers.component.html',
  styleUrls: ['./showallcustomers.component.css']
})
export class ShowallcustomersComponent implements OnInit {
  result: any
  submitted = false;
  submit = false;
  output: any
  constructor(private service: LoginService) { }

  ngOnInit() {
    this.printTransaction()
  }
  printTransaction(): void {
    this.service.viewcustomers().subscribe(data => {
      this.result = data;
      this.submit = true;

      console.log(this.result);
    });
  }
  deletecustomer(customerId): void {
    console.log(customerId)
    this.service.removecustomers(customerId).subscribe(data => {
      this.output = data;
      this.submit = true;
      window.location.reload();
    })
  }
}
