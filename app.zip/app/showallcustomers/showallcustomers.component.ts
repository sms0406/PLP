import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service'

@Component({
  selector: 'app-showallcustomers',
  templateUrl: './showallcustomers.component.html',
  styleUrls: ['./showallcustomers.component.css']
})
export class ShowallcustomersComponent implements OnInit {
  result: any
  submitted = false;
  submit = false;
  output: any
  constructor(private service: LoginService) { }

  ngOnInit() {
    // alert(sessionStorage.getItem("first"))
    this.printTransaction()
  }
  printTransaction(): void {
    this.service.viewcustomers().subscribe(data => {
      this.result = data;
      this.submitted = true;

      console.log(this.result);
    });
  }
  deletecustomers(customerId):void {
    this.service.removecustomers(customerId).subscribe(data => {
     this.output=data;
     
     this.result=data;
     alert(this.result)
     window.location.reload();

    })
  }
}
