import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  result: any;
  model;
  constructor(private router: Router, private service: LoginService) { }
  a: any;
  
  ngOnInit() {
  }
  login(add) {
    if (add.email != null && add.password != null) {
      if (add.choice == "admin") {
        this.service.adminlogin(add).subscribe(data => {
          this.result = data
          if (this.result == "Login Successful") {
            alert(this.result)
            this.router.navigate(['/adminmanage'])
          }
          else {
            console.log(this.result)
            alert(this.result)
          }
        });
      }
      else {
        alert("This is not admin page")
      }


      //console.log(add.email)
      //console.log(add.password)


    }
    else{
      alert("Values cannot be empty")

    }
  }
}
