import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from '../../node_modules/rxjs';
@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private baseUrl='http://localhost:3456';
  constructor(private http:HttpClient) { }


  public adminlogin(admin):Observable<String>{
    return this.http.get(`${this.baseUrl}/login/${admin.email}/${admin.password}`,{responseType:"text"});
  }
  public viewmerchants():Observable<any>
  {
    return this.http.get(`${this.baseUrl}/login/`)
  }
  
  public deleteMerchant(merchantId):Observable<String>
  {
    return this.http.delete(`${this.baseUrl}/login`+`/`+`${merchantId}`,{responseType:"text"})
  }
  public vieworders():Observable<any>
  {
    return this.http.get(`${this.baseUrl}/login/orders`)
  }
  public deleteOrder(order_id):Observable<String>
  {
    return this.http.delete(`${this.baseUrl}/login`+`/`+`orders`+`/`+`${order_id}`,{responseType:"text"})
  }
  public viewcustomers():Observable<any>
  {
    return this.http.get(`${this.baseUrl}/login/showCustomers/`)
  }
  public removecustomers(customerId):Observable<any>
  {
    return this.http.delete(`${this.baseUrl}/login`+`/`+`/deleteCustomers/`+`${customerId}`,{responseType:"text"})
  }

  public updateStatus(order_id):Observable<any>
  {
    return this.http.put(`${this.baseUrl}/login`+`/`+`/orders/`+`/`+`/status/`+`${order_id}`,{responseType:"text"})
    
}}
