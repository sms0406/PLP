import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service'
@Component({
  selector: 'app-viewcustomers',
  templateUrl: './viewcustomers.component.html',
  styleUrls: ['./viewcustomers.component.css']
})
export class ViewcustomersComponent implements OnInit {
  result: any
  submitted = false;
  submit = false;
  output:any
  constructor(private service: LoginService) { }

  ngOnInit() {
    this.printTransaction()
  }
  printTransaction(): void {
    this.service.viewcustomers().subscribe(data => {
      this.result = data;
      this.submitted = true;

      console.log(this.result);
    });
  }
  deletecustomers():void{
    this.service.removecustomers().subscribe(data =>{
      this.output = data;
      this.submit=true;
    })
  }
}
