import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from './login/login.component';
import {SignupComponent} from './signup/signup.component';
import {AdminmanageComponent} from './adminmanage/adminmanage.component'
import { ShowallmerchantsComponent } from './showallmerchants/showallmerchants.component'
import { ShowallcustomersComponent } from './showallcustomers/showallcustomers.component'
import {ShowallordersComponent} from './showallorders/showallorders.component'
import { DeliverystatusComponent } from './deliverystatus/deliverystatus.component';
import { fromEventPattern } from '../../node_modules/rxjs';
import {InventoryComponent} from './inventory/inventory.component'
const routes: Routes = [
  { path:  '', component:  LoginComponent},
  { path:  'signup', component:  SignupComponent},
  { path: 'adminmanage', component: AdminmanageComponent},
  { path: 'showallmerchants', component:ShowallmerchantsComponent},
  {path:'showallcustomers', component: ShowallcustomersComponent},
  { path:'showallorders',component:ShowallordersComponent},
  { path:'deliverystatus' , component:DeliverystatusComponent},
  {path :'inventory', component:InventoryComponent}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
