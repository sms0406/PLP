package com.capstore.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capstore.service.CapStoreImpl;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class Controller {
	@Autowired
	CapStoreImpl service;

	@GetMapping(value = "/login/{email}/{password}")
	public ResponseEntity<String> login(@PathVariable("email") String email,
			@PathVariable("password") String password) {
		String returnType = service.login(email, password);
		RequestResponse result = new RequestResponse(true,returnType);
		return new ResponseEntity<String>(returnType, HttpStatus.OK);
	}

}

