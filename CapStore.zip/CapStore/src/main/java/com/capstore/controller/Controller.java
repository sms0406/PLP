package com.capstore.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.model.CustomerEntity;
import com.capstore.model.Customer_Orders;
import com.capstore.model.Customers;
import com.capstore.model.Merchants;
import com.capstore.model.Products;
import com.capstore.service.CapStoreImpl;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class Controller {
	@Autowired
	CapStoreImpl service;

	@GetMapping(value = "/login/{email}/{password}")
	public ResponseEntity<String> login(@PathVariable("email") String email, @PathVariable("password") String password)
			throws Exception {
		String returnType = service.login(email, password);
		// RequestResponse result = new RequestResponse(true,returnType);
		return new ResponseEntity<String>(returnType, HttpStatus.OK);
	}

	@GetMapping(value = "/login/")
	public ResponseEntity<List<Merchants>> getMerchants() {
		List<Merchants> list = new ArrayList<>();
		list = service.getMerchant();
		return ResponseEntity.ok(list);
	}

	@DeleteMapping(value = "/login/{merchantId}")
	public ResponseEntity<String> deleteMerchant(@PathVariable("merchantId") int merchantId) {
		String result = service.deleteMerchant(merchantId);
		return new ResponseEntity<String>(result, HttpStatus.OK);
	}

	@GetMapping(value = "/login/orders")
	public ResponseEntity<List<Customer_Orders>> showOrder() {
		List<Customer_Orders> list = new ArrayList<>();
		list = service.showOrders();
		return ResponseEntity.ok(list);
	}

	@DeleteMapping(value = "/login/orders/{order_id}")
	public ResponseEntity<String> deleteOrder(@PathVariable("order_id") int order_id) {
		String result = service.deleteOrder(order_id);
		return new ResponseEntity<String>(result, HttpStatus.OK);
	}

	@GetMapping(value = "/login/showCustomers/")
	public ResponseEntity<List<Customers>> getCustomers() {
		List<Customers> list = new ArrayList<>();
		list = service.getCustomers();
		return ResponseEntity.ok(list);
	}

	@DeleteMapping(value = "/login/deleteCustomers/{customerId}")
	public String deleteCustomer(@PathVariable("customerId") Long customerId) {
		return service.deleteCustomers(customerId);
	}

	@PutMapping(value = "/login/orders/status/{order_id}")
	public ResponseEntity<String> updateStatus(@PathVariable("order_id") int order_id) {

		String status = service.updateDeliveryStatus(order_id);
		return new ResponseEntity<String>(status, HttpStatus.OK);
	}

	/************************************************************/

	// Login Merchant

	@GetMapping(value = "/loginMerchant/{email}/{password}")
	public ResponseEntity<String> loginMerchant(@PathVariable("email") String email,
			@PathVariable("password") String password) throws Exception {
		String returnType = service.loginMerchant(email, password);
		// RequestResponse result = new RequestResponse(true,returnType);
		return new ResponseEntity<String>(returnType, HttpStatus.OK);
	}
	// SignUp Merchant

	@PostMapping(value = "/merchant")
	public ResponseEntity<String> addCustomer(@RequestBody Merchants m) throws Exception {
		String result = service.addMerchant(m);
		// return new ResponseEntity<User>(result, HttpStatus.OK);
		return new ResponseEntity<String>(result, HttpStatus.OK);
	}

	// Show Inventory
	@GetMapping(value = "/login/showinventory/{merchantId}")
	public ResponseEntity<List<Products>> showInventory(@PathVariable("merchantId") Long merchantId) {
		List<Products> list = new ArrayList<>();
		list = service.showInventory(merchantId);
		return ResponseEntity.ok(list);
	}

	/**
	 * @throws Exception *******************************************************************************/
	// Customer Signup
	
	  @PostMapping(value = "/customer") 
	  public ResponseEntity<CustomerEntity>addCustomer(@RequestBody CustomerEntity cust) throws Exception 
	  { 
		  CustomerEntity result =service.insertCustomer(cust); 
		  return new ResponseEntity<CustomerEntity>(result,HttpStatus.OK); 
	  }
	 // CustomerLogin

	@GetMapping(value = "/loginCustomer/{email}/{password}")
	public ResponseEntity<String> loginCustomer(@PathVariable("email") String email,
			@PathVariable("password") String password) throws Exception {
		String returnType = service.loginCustomer(email, password);
		RequestResponse result = new RequestResponse(true, returnType);
		return new ResponseEntity<String>(returnType, HttpStatus.OK);
	}

}
