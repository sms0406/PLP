package com.capstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.model.Customers;

public interface CustomerRepository extends JpaRepository<Customers, Long>{
	
}
