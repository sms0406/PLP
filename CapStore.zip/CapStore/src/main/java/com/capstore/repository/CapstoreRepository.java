package com.capstore.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.model.AdminLogin;

public interface CapstoreRepository extends JpaRepository<AdminLogin, String> {

}
