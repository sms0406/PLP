package com.capstore.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capstore.model.Products;

public interface InventoryRepository extends JpaRepository<Products, Long> {
	@Query("from Products p where p.merchantId = ?1")
	public List<Products> findByMerchant(long merchantId);

}
