package com.capstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.model.Customer_Orders;

public interface CustomerOrderRepository extends JpaRepository<Customer_Orders, Integer> {

}
