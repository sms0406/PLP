package com.capstore.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capstore.model.Merchants;

public interface MerchantRepositoryAccounts extends JpaRepository<Merchants, Long> {

	@Query("from Merchants m where m.email = :email")
	Optional<Merchants> findByEmail(@Param("email") String email);

}
