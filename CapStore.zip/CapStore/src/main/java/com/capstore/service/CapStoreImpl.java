package com.capstore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.model.AdminLogin;
import com.capstore.model.Merchants;
import com.capstore.model.Customers;

import com.capstore.model.Customer_Orders;
import com.capstore.repository.CustomerOrderRepository;
import com.capstore.repository.CustomerRepository;
import com.capstore.repository.CapstoreRepository;
import com.capstore.repository.MerchantRepository;

@Service
@Transactional
public class CapStoreImpl implements ICapStore {
	@Autowired
	CapstoreRepository repository;
	@Autowired
	MerchantRepository merchantRepository;
	@Autowired
	CustomerOrderRepository orderRepository;
	@Autowired
	CustomerRepository customerRepository;

	public String login(String email, String password) {

		Optional<AdminLogin> opt = repository.findById(email);
		if (opt.isPresent()) {
			AdminLogin login = opt.get();
			if (login.getPassword().equals(password)) {
				System.out.println("Successful");
				return "Login Successful";
			} else {
				System.out.println("Failure");
				return "Login Failed";
			}
		} else {
			return "Login Failed";
		}

	}

	public List<Merchants> getMerchant() {

		List<Merchants> list = new ArrayList<Merchants>();
		list = merchantRepository.findAll();
		return list;
	}

	@Override
	public String deleteMerchant(long merchantId) {
		Optional<Merchants> opt = merchantRepository.findById(merchantId);
		if (opt.isPresent()) {
			Merchants merchants = opt.get();
			merchantRepository.delete(merchants);
			return "Merchant details deleted successfully";

		} else {
			return "Merchant Not Found";
		}

	}

	@Override
	public List<Customer_Orders> showOrders() {

		List<Customer_Orders> list = new ArrayList<Customer_Orders>();
		list = orderRepository.findAll();
		return list;
	}

	@Override
	public String deleteOrder(int order_id) {
		Optional<Customer_Orders> opt = orderRepository.findById(order_id);
		if (opt.isPresent()) {
			Customer_Orders order = opt.get();
			orderRepository.delete(order);
			return "Order deleted successfully";

		} else {
			return "Order Not Found";
		}

	}

	public List<Customers> getCustomers() {
		List<Customers> list = new ArrayList<Customers>();
		list = customerRepository.findAll();
		return list;
	}

	public String deleteCustomers(long customerId) {
		Optional<Customers> opt = customerRepository.findById(customerId);
		if (opt.isPresent()) {
			Customers customer = opt.get();
			customerRepository.delete(customer);
		} else {
			return "Customer with " + customerId + " does not exist";
		}
		return "Customer details deleted successfully";
	}

	public String updateDeliveryStatus(int order_id) {
		String status = null;
		Optional<Customer_Orders> opt = orderRepository.findById(order_id);
		if (opt.isPresent()) {
			Customer_Orders customerOrder = opt.get();
			status = customerOrder.getDeliveryStatus();
			if (status.equalsIgnoreCase("Delivered")) {
				customerOrder.setCustomer_id(customerOrder.getCustomer_id());
				customerOrder.setProduct_name(customerOrder.getProduct_name());
				customerOrder.setOrder_id(customerOrder.getOrder_id());
				customerOrder.setQuantity(customerOrder.getQuantity());
				customerOrder.setAmount(customerOrder.getAmount());
				customerOrder.setDeliveryStatus("Not Delivered");
				orderRepository.saveAndFlush(customerOrder);
			} else {
				customerOrder.setCustomer_id(customerOrder.getCustomer_id());
				customerOrder.setProduct_name(customerOrder.getProduct_name());
				customerOrder.setOrder_id(customerOrder.getOrder_id());
				customerOrder.setQuantity(customerOrder.getQuantity());
				customerOrder.setAmount(customerOrder.getAmount());
				customerOrder.setDeliveryStatus("Delivered");
				orderRepository.saveAndFlush(customerOrder);
			}

		}
		return status;
	}
}
