package com.capstore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.model.AdminLogin;
import com.capstore.model.CustomerEntity;
import com.capstore.model.Customer_Orders;
import com.capstore.model.Customers;
import com.capstore.model.Merchants;
import com.capstore.model.Products;
import com.capstore.repository.CapstoreRepository;
import com.capstore.repository.CustomerLoginRepository;
import com.capstore.repository.CustomerOrderRepository;
import com.capstore.repository.CustomerRepository;
import com.capstore.repository.InventoryRepository;
import com.capstore.repository.MerchantRepository;
import com.capstore.repository.MerchantRepositoryAccounts;

@Service
@Transactional
public class CapStoreImpl implements ICapStore {
	@Autowired
	CapstoreRepository repository;
	@Autowired
	MerchantRepository merchantRepository;
	@Autowired
	CustomerOrderRepository orderRepository;
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	MerchantRepositoryAccounts merchantAccounts;
	@Autowired
	InventoryRepository inventRepository;
	@Autowired
	CustomerLoginRepository loginrepo;
	
	public String login(String email, String password) throws Exception {

		Optional<AdminLogin> opt = repository.findById(email);
		if (opt.isPresent()) {
			AdminLogin login = opt.get();
			String passwordDec = SecurePassword.decrypt(login.getPassword());
			if (passwordDec.equals(password)) {
				System.out.println("Successful");
				return "Login Successful";
			} else {
				System.out.println("Failure");
				return "Login Failed";
			}
		} else {
			return "Login Failed";
		}

	}

	public List<Merchants> getMerchant() {

		List<Merchants> list = new ArrayList<Merchants>();
		list = merchantRepository.findAll();
		return list;
	}

	@Override
	public String deleteMerchant(long merchantId) {
		Optional<Merchants> opt = merchantRepository.findById(merchantId);
		if (opt.isPresent()) {
			Merchants merchants = opt.get();
			merchantRepository.delete(merchants);
			return "Merchant details deleted successfully";

		} else {
			return "Merchant Not Found";
		}

	}

	@Override
	public List<Customer_Orders> showOrders() {

		List<Customer_Orders> list = new ArrayList<Customer_Orders>();
		list = orderRepository.findAll();
		return list;
	}

	@Override
	public String deleteOrder(int order_id) {
		Optional<Customer_Orders> opt = orderRepository.findById(order_id);
		if (opt.isPresent()) {
			Customer_Orders order = opt.get();
			orderRepository.delete(order);
			return "Order deleted successfully";

		} else {
			return "Order Not Found";
		}

	}

	public List<Customers> getCustomers() {
		List<Customers> list = new ArrayList<Customers>();
		list = customerRepository.findAll();
		return list;
	}

	public String deleteCustomers(long customerId) {
		Optional<Customers> opt = customerRepository.findById(customerId);
		if (opt.isPresent()) {
			Customers customer = opt.get();
			customerRepository.delete(customer);
		} else {
			return "Customer with " + customerId + " does not exist";
		}
		return "Customer details deleted successfully";
	}

	public String updateDeliveryStatus(int order_id) {
		String status = null;
		Optional<Customer_Orders> opt = orderRepository.findById(order_id);
		if (opt.isPresent()) {
			Customer_Orders customerOrder = opt.get();
			status = customerOrder.getDeliveryStatus();
			if (status.equalsIgnoreCase("Delivered")) {
				customerOrder.setCustomer_id(customerOrder.getCustomer_id());
				customerOrder.setProduct_name(customerOrder.getProduct_name());
				customerOrder.setOrder_id(customerOrder.getOrder_id());
				customerOrder.setQuantity(customerOrder.getQuantity());
				customerOrder.setAmount(customerOrder.getAmount());
				customerOrder.setDeliveryStatus("Not Delivered");
				orderRepository.saveAndFlush(customerOrder);
			} else {
				customerOrder.setCustomer_id(customerOrder.getCustomer_id());
				customerOrder.setProduct_name(customerOrder.getProduct_name());
				customerOrder.setOrder_id(customerOrder.getOrder_id());
				customerOrder.setQuantity(customerOrder.getQuantity());
				customerOrder.setAmount(customerOrder.getAmount());
				customerOrder.setDeliveryStatus("Delivered");
				orderRepository.saveAndFlush(customerOrder);
			}

		}
		return status;
	}

	/*****************************************************************************/
	// Merchant Sign Up

	public String addMerchant(Merchants m) throws Exception{
		Merchants entity =  new Merchants();
		//password encrypt and decrypt
		String password=m.getPassword();
        String passwordEnc = SecurePassword.encrypt(password);
        m.setPassword(passwordEnc);
		entity.setMerchantName(m.getMerchantName());	
		entity.setPhoneNo(m.getPhoneNo());
		entity.setEmail(m.getEmail());
		entity.setPassword(m.getPassword());
		entity.setGovtProofType(m.getGovtProofType());
		entity.setGovtProof(m.getGovtProof());
		merchantAccounts.save(entity);
		return "redirecting to your final step of signing up";
	} 
	// Merchant Login

	public String loginMerchant(String email, String password) throws Exception {
		
		Optional<Merchants> opt = merchantAccounts.findByEmail(email);
		if (opt.isPresent()) {
			Merchants login = opt.get();
			String passwordDec = SecurePassword.decrypt(login.getPassword());
			if (passwordDec.equals(password)) {
				System.out.println("Successful");
				return "Login Successful";
			} else {
				System.out.println("Failure");
				return "Login Failed";
			}
		} else {
			return "Login Failed";
		}

	}
	
	//Show Inventory
	@Override
	public List<Products> showInventory(long merchantId) {
		List<Products> list  = inventRepository.findByMerchant(merchantId);
		return list;
	}
	
	
	/***********************************************************************/
	//Customer login
	@Override
	public String loginCustomer(String email, String password) throws Exception{
		Optional<CustomerEntity> opt = loginrepo.findByEmail(email);
		if (opt.isPresent()) {
			CustomerEntity login = opt.get();
			String passwordDec = SecurePassword.decrypt(login.getPassword());
			if (passwordDec.equals(password)) {
				System.out.println("Successful");
				return "Login Successful";
			} else {
				System.out.println("Failure");
				return "Login Failed";
			}
		} else {
			return "Login Failed";
		}
	}
	
	@Override
	public CustomerEntity insertCustomer(CustomerEntity customer) throws Exception {
		
		CustomerEntity entity = new CustomerEntity();
		String password=customer.getPassword();
        String passwordEnc = SecurePassword.encrypt(password);
        customer.setPassword(passwordEnc);
		entity.setName(customer.getName());
		entity.setEmail(customer.getEmail());
		entity.setAddress(customer.getAddress());
		entity.setMobileNo(customer.getMobileNo());
		entity.setPassword(customer.getPassword());
		return loginrepo.saveAndFlush(customer);

	}
	
}
