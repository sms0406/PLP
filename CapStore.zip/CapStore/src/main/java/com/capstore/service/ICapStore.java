package com.capstore.service;

public interface ICapStore {
	public String login(String email, String password);
}
