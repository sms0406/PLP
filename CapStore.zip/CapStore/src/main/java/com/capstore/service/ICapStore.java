package com.capstore.service;

import java.util.List;

import com.capstore.model.Customer_Orders;
import com.capstore.model.Customers;
import com.capstore.model.Merchants;

public interface ICapStore {
	public String login(String email, String password);

	public List<Merchants> getMerchant();

	public String deleteMerchant(long merchantId);

	public List<Customer_Orders> showOrders();

	public String deleteOrder(int order_id);

	public List<Customers> getCustomers();

	public String deleteCustomers(long customerId);
	
	public String updateDeliveryStatus(int order_id);
}
