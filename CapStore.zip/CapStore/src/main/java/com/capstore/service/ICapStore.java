package com.capstore.service;

import java.util.List;

import com.capstore.model.CustomerEntity;
import com.capstore.model.Customer_Orders;
import com.capstore.model.Customers;
import com.capstore.model.Merchants;
import com.capstore.model.Products;

public interface ICapStore {
	public String login(String email, String password) throws Exception;

	public List<Merchants> getMerchant();

	public String deleteMerchant(long merchantId);

	public List<Customer_Orders> showOrders();

	public String deleteOrder(int order_id);

	public List<Customers> getCustomers();

	public String deleteCustomers(long customerId);
	
	public String updateDeliveryStatus(int order_id);
	
	public String addMerchant(Merchants m) throws Exception;
	
	public String loginMerchant(String email, String password) throws Exception;
	
	public List<Products> showInventory(long merchantId);
	
	public String loginCustomer(String email, String password) throws Exception;
	
	public CustomerEntity insertCustomer(CustomerEntity customer) throws Exception;

}
