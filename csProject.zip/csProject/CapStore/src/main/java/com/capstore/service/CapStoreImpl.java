package com.capstore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.model.AdminLogin;
import com.capstore.model.Merchants;
import com.capstore.model.Customers;

import com.capstore.model.Customer_Orders;
import com.capstore.repository.CustomerOrderRepository;
import com.capstore.repository.CustomerRepository;
import com.capstore.repository.CapstoreRepository;
import com.capstore.repository.MerchantRepository;

@Service
@Transactional
public class CapStoreImpl implements ICapStore {
	@Autowired
	CapstoreRepository repository;
	@Autowired
	MerchantRepository merchantRepository;
	@Autowired
	CustomerOrderRepository orderRepository;
	@Autowired
	CustomerRepository customerRepository;
	
	
	

	public String login(String email, String password) throws Exception {

		Optional<AdminLogin> opt = repository.findById(email);
		if (opt.isPresent()) {
			AdminLogin login = opt.get();
			String passwordDec = SecurePassword.decrypt(login.getPassword());
			if (passwordDec.equals(password)) {
				System.out.println("Successful");
				return "Login Successful";
			} else {
				System.out.println("Failure");
				return "Login Failed";
			}
		} else {
			return "Login Failed";
		}

	}

	public List<Merchants> getMerchant() {

		List<Merchants> list = new ArrayList<Merchants>();
		list = merchantRepository.findAll();
		return list;
	}

	@Override
	public String deleteMerchant(long merchantId) {
		Optional<Merchants> opt = merchantRepository.findById(merchantId);
		if (opt.isPresent()) {
			Merchants merchants = opt.get();
			merchantRepository.delete(merchants);
			return "Merchant details deleted successfully";

		} else {
			return "Merchant Not Found";
		}

	}

	@Override
	public List<Customer_Orders> showOrders() {

		List<Customer_Orders> list = new ArrayList<Customer_Orders>();
		list = orderRepository.findAll();
		return list;
	}

	@Override
	public String deleteOrder(int order_id) {
		Optional<Customer_Orders> opt = orderRepository.findById(order_id);
		if (opt.isPresent()) {
			Customer_Orders order = opt.get();
			orderRepository.delete(order);
			return "Order deleted successfully";

		} else {
			return "Order Not Found";
		}

	}

	public List<Customers> getCustomers() {
		List<Customers> list = new ArrayList<Customers>();
		list = customerRepository.findAll();
		return list;
	}

	public String deleteCustomers(long customerId) {
		Optional<Customers> opt = customerRepository.findById(customerId);
		if (opt.isPresent()) {
			Customers customer = opt.get();
			customerRepository.delete(customer);
		} else {
			return "Customer with " + customerId + " does not exist";
		}
		return "Customer details deleted successfully";
	}

	public Customers createUserAccount(Customers user) throws Exception {
		Customers entity =  new Customers();
		
		
		
		//password encrypt and decrypt
		String password=user.getPassword();
        String passwordEnc = SecurePassword.encrypt(password);
        String passwordDec = SecurePassword.decrypt(passwordEnc);

        System.out.println("Encrypted Text : " + passwordEnc);
        System.out.println("Decrypted Text : " + passwordDec);
        user.setPassword(passwordEnc);
		entity.setCustomerName(user.getCustomerName());	
		entity.setEmail(user.getEmail());
		entity.setGender(user.getGender());
		entity.setAddress(user.getAddress());
		entity.setMobileNo(user.getMobileNo());
		entity.setPassword(user.getPassword());
		return customerRepository.saveAndFlush(user);
	}

}
